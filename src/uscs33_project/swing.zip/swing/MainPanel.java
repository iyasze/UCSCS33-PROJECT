package uscs33_project.swing;

import javax.swing.JPanel;

public class MainPanel extends JPanel {
    public MainPanel() {
        setOpaque(false);
    }
}
